Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "C:\datalogv1.1\logger.bat", 0