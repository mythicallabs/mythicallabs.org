@echo off
cd C:\datalogv1.1
start /B python.exe main.py